
mfbvar
======

[![Build Status](https://travis-ci.org/ankargren/mfbvar.svg?branch=master)](https://travis-ci.org/ankargren/mfbvar) [![](http://www.r-pkg.org/badges/version/mfbvar)](https://www.r-pkg.org:443/pkg/mfbvar) [![Coverage status](https://codecov.io/gh/ankargren/mfbvar/branch/master/graph/badge.svg)](https://codecov.io/github/ankargren/mfbvar?branch=master)

Overview
--------

The `mfbvar` package implements Bayesian mixed-frequency VAR models.

Installation
------------

The current development version of the package can be installed with the help of `devtools`:

``` r
devtools::install_github("ankargren/mfbvar")
```

Usage
-----

See the vignette for details and examples.
