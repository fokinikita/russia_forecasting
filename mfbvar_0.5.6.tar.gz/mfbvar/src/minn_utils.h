#ifndef _MINN_UTILS_H_
#define _MINN_UTILS_H_
arma::mat create_X_t(const arma::mat & y);
arma::mat create_X(const arma::mat & y, arma::uword k);
#endif
